Start-Transcript -Path C:\Windows\Logs\Install-KioskConfig.log

# Install kioskmode package.
Install-ProvisioningPackage -PackagePath .\KioskMode.ppkg -QuietInstall

# Copy scripts.
$folderPath = "C:\Windows\Tasks\Kiosk"
New-Item -Path $folderPath -ItemType Directory -Force
Copy-Item ".\Task-KioskConfig.ps1" -Destination $folderPath -Force
Copy-Item ".\accounts.txt" -Destination $folderPath -Force

#************************* Kiosk config scheduled task *********************************
# Run tasks as local system.
$taskUsername = "System"

# Delete, if task already exist.
$taskName = "Kiosk config"
Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue

# Create a new task action.
$taskAction = New-ScheduledTaskAction `
    -Execute 'powershell.exe ' `
    -Argument "-ExecutionPolicy Bypass -File $folderPath\Task-KioskConfig.ps1"
$taskAction

# Register scheduled task.
$taskDescription = $taskName
$taskTrigger1 = New-ScheduledTaskTrigger -AtStartup
Register-ScheduledTask `
    -TaskName $taskName `
    -Action $taskAction `
    -Trigger $taskTrigger1 `
    -User $taskUsername `
    -RunLevel Highest `
    -Description $taskDescription

# Run the scheduled task.
Start-Sleep 1
Get-ScheduledTask -TaskName $taskName1 | Start-ScheduledTask
#***************************************************************************************

# Autologon as kioskuser0
Set-Itemproperty -path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' -Name 'DefaultUserName' -value 'kioskUser0'
Set-Itemproperty -path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' -Name 'DefaultPassword' -value ''
Set-Itemproperty -path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' -Name 'AutoAdminLogon' -value '1'

# Skip first logon animation.
[Microsoft.Win32.Registry]::SetValue("HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System","EnableFirstLogonAnimation",0,[Microsoft.Win32.RegistryValueKind]::DWord)

# Skip OOBE privacy settings.
[Microsoft.Win32.Registry]::SetValue("HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\OOBE","DisablePrivacyExperience",1,[Microsoft.Win32.RegistryValueKind]::DWord)

Stop-Transcript