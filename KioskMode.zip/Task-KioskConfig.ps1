Start-Transcript -Path C:\Windows\Logs\Task-KioskConfig.log

#************************* Configure shortcut parameters ******************************
function Set-Shortcut($shortcutLocation, $shortcutArguments, $shortcutTargetPath) {
    $WScriptShell = New-Object -ComObject WScript.Shell
    $shortcut = $WScriptShell.CreateShortcut($shortcutLocation)
    $shortcut.TargetPath = $shortcutTargetPath
    $shortcut.Arguments = "$shortcutArguments"
    $shortcut.Save()
}

# Variables
$shortcutLocation = "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Notepad++.lnk"
$shortcutTargetPath = "C:\Program Files (x86)\Notepad++\notepad++.exe"
# $shortcutArguments = "CONNECTION_STRING=https://fqdn USER_ID=***** PASSWORD=*****"
# Set-Shortcut $shortcutLocation $shortcutArguments $shortcutTargetPath
# Get accounts from text file.
$accountsTxt = Get-Content -raw "c:\Windows\Tasks\kiosk\accounts.txt" | ConvertFrom-StringData
# Update shortcut arguments if matching computername
foreach($item in $accountsTxt){
    $item.$env:COMPUTERNAME
    Set-Shortcut $shortcutLocation $item.$env:COMPUTERNAME $shortcutTargetPath
}
#***************************************************************************************

# Autologon as kioskuser0
Set-Itemproperty -path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' -Name 'DefaultUserName' -value 'kioskUser0'
Set-Itemproperty -path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' -Name 'DefaultPassword' -value ''
Set-Itemproperty -path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' -Name 'AutoAdminLogon' -value '1'

# Skip first logon animation.
[Microsoft.Win32.Registry]::SetValue("HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System","EnableFirstLogonAnimation",0,[Microsoft.Win32.RegistryValueKind]::DWord)

# Skip OOBE privacy settings.
[Microsoft.Win32.Registry]::SetValue("HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\OOBE","DisablePrivacyExperience",1,[Microsoft.Win32.RegistryValueKind]::DWord)

Stop-Transcript